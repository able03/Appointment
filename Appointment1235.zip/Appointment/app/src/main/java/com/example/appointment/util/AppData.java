package com.example.appointment.util;

public class AppData {

    public static final String Sender_Email_Address ="codefestfinal@gmail.com";
    public static final String Sender_Email_Password="rikmwnwlanhyinxk";
    public static final String Receiver_Email_Address="rblox156@gmail.com";

    public static final String Gmail_Host = "smtp.gmail.com";



}
