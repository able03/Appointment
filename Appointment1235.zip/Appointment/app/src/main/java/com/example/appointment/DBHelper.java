package com.example.appointment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    Context context;
    String sql;
    public DBHelper(@Nullable Context context) {
        super(context, "AppointmentDatabase", null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        sql = "CREATE TABLE IF NOT EXISTS student(id INTEGER PRIMARY KEY AUTOINCREMENT, first_name VARCHAR, last_name VARCHAR, contact VARCHAR, email VARCHAR, pin INTEGER)";
        db.execSQL(sql);

        sql = "CREATE TABLE IF NOT EXISTS teacher(teacher_id INTEGER PRIMARY KEY AUTOINCREMENT, name VARCHAR, pin INTEGER)";
        db.execSQL(sql);

        sql = "CREATE TABLE IF NOT EXISTS subject(subject_id INTEGER PRIMARY KEY AUTOINCREMENT, subject_name VARCHAR, teacher_id INTEGER)";
        db.execSQL(sql);

        sql = "CREATE TABLE IF NOT EXISTS appointment(appointment_id INTEGER PRIMARY KEY AUTOINCREMENT, year VARCHAR, month VARCHAR, day VARCHAR, time VARCHAR, subject VARCHAR, teacher_name VARCHAR, purpose VARCHAR, teacher_id)";
        db.execSQL(sql);
    }

    public Cursor FindStudentAccount(int pin){
        SQLiteDatabase db = this.getWritableDatabase();
        sql = "SELECT * FROM student WHERE pin = '"+pin+"'";
        Cursor c = db.rawQuery(sql, null);
        return c;
    }

    public boolean createStudentAccount(String fn, String ln, String contact, String email, int pin){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("first_name", fn);
        cv.put("last_name", ln);
        cv.put("contact", contact);
        cv.put("email", email);
        cv.put("pin", pin);
        long res = db.insert("student", null, cv);
        if(res == -1){
            return false;
        }else{
            return true;
        }

    }

    public boolean createTeacherAccount(String name, int pin){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("pin", pin);
        long res = db.insert("teacher", null, cv);
        if(res == -1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor getTeacherCount()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT COUNT(*) FROM teacher", null);
    }

    public boolean createSubject(String subject_name, int teacher_id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("subject_name", subject_name);
        cv.put("teacher_id", teacher_id);
        long res = db.insert("subject", null, cv);
        if(res == -1){
            return false;
        }else{
            return true;
        }
    }

    public boolean createAppointment(int year, int month, int day, String time, String subject, String teacher_name, String purpose, int teacher_id){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("year", year);
        cv.put("month", month);
        cv.put("day", day);
        cv.put("time", time);
        cv.put("subject", subject);
        cv.put("teacher_name", teacher_name);
        cv.put("purpose", purpose);
        cv.put("teacher_id", teacher_id);
        long res = db.insert("appointment", null, cv);
        if(res == -1){
            return false;
        }else{
            return true;
        }

    }

    public Cursor getTeacher(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        sql = "SELECT * FROM teacher WHERE name = '"+name+"'";
        Cursor c = db.rawQuery(sql,null);
        return c;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
