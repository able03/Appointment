package com.example.appointment.models;

public class CalendarModel {
    private String year;
    private String month;
    private String dayOfMonth;
}
