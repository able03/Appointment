package com.example.appointment.activities;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.applandeo.materialcalendarview.CalendarDay;
import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.listeners.OnCalendarDayClickListener;
import com.example.appointment.R;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class TeacherMainActivity extends AppCompatActivity {

    CalendarView calendarView;
    ListView listView;
    TextView tv_teacher_name;
    List<CalendarDay> calendarList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_teacher_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initValues();
        setAppointmentDates();
        setListener();




    }

    private void initValues() {
        calendarView = findViewById(R.id.calendar);
        listView = findViewById(R.id.lv_my_appointments);
        tv_teacher_name = findViewById(R.id.tv_teacher_name);
        calendarList = new ArrayList<>();
    }

    private void setAppointmentDates()
    {
        Calendar c1 = Calendar.getInstance();
        c1.set(2024, 4, 11);
        CalendarDay day1 = new CalendarDay(c1);
        day1.setImageResource(R.drawable.ic_note);
        calendarList.add(day1);


        calendarView.setCalendarDays(calendarList);

    }

    private void setListener()
    {
        calendarView.setOnCalendarDayClickListener(new OnCalendarDayClickListener() {
            @Override
            public void onClick(@NonNull CalendarDay calendarDay) {
                if(calendarList.contains(calendarDay))
                {
                    Log.d("Debugging", "selected");
                }
            }
        });

    }

}
