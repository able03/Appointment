package com.example.appointment.fragments;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.example.appointment.DBHelper;
import com.example.appointment.activities.MainActivity;
import com.example.appointment.models.StudentStaticModel;
import com.example.appointment.R;
import com.example.appointment.activities.StudentMainActivity;
import com.google.android.material.button.MaterialButton;


public class LoginFragment extends Fragment {


    MaterialButton btn_login;

    DBHelper db;

    EditText et1, et2, et3, et4;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initValues();
        setPin();

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newPin = et1.getText().toString() + et2.getText().toString() + et3.getText().toString() + et4.getText().toString();
                Cursor c = db.FindStudentAccount(Integer.valueOf(newPin));
                c.moveToFirst();
                if(c.getCount() > 0 ){
                    int id = c.getInt(0);
                    String fn = c.getString(1);
                    String ln = c.getString(2);
                    String contact = c.getString(3);
                    String email = c.getString(4);
                    int pin = c.getInt(5);

                    new StudentStaticModel(fn, ln, contact, email, pin);
                    Intent i = new Intent(getContext(), StudentMainActivity.class);
                    startActivity(i);

                    Toast.makeText(getContext(), "Account found", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getContext(), "Account not found", Toast.LENGTH_SHORT).show();
                }
                /*if(db.FindStudentAccount(Integer.valueOf(newPin))){
                    Intent i = new Intent(getContext(), StudentMainActivity.class);
                    startActivity(i);
                    Toast.makeText(getContext(), "Account login successful", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getContext(), "Account login failed", Toast.LENGTH_SHORT).show();
                }*/
            }
        });
    }


    private void initValues()
    {

        db = new DBHelper(getContext());
        et1 = getView().findViewById(R.id.et1);
        et2 = getView().findViewById(R.id.et2);
        et3 = getView().findViewById(R.id.et3);
        et4 = getView().findViewById(R.id.et4);
        btn_login = getView().findViewById(R.id.btn_login);
    }

    private void setPin()
    {
        et1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length() == 1)
                {
                    et2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        et2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length() == 1)
                {
                    et3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        et3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length() == 1)
                {
                    et4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


        et1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.length() == 1)
                {
                    et2.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }






}