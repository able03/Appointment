package com.example.appointment.models;



public class StudentStaticModel {
    private static String first_name;
    private static String last_name;
    private static String contact;
    private static String email;
    private static int pin;

    public StudentStaticModel(String first_name, String last_name, String contact, String email, int pin) {
        this.first_name = first_name;
        this.last_name = last_name;
        this.contact = contact;
        this.email = email;
        this.pin = pin;
    }

    public static String getFirst_name() {
        return first_name;
    }

    public static String getLast_name() {
        return last_name;
    }

    public static String getContact() {
        return contact;
    }

    public static String getEmail() {
        return email;
    }

    public static int getPin() {
        return pin;
    }
}
